package android.com.dream_detector

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentContainerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : FragmentActivity() {

    private var isFabOpen = false

    @RequiresApi(Build.VERSION_CODES.O)
    @SuppressLint("SetTextI18n")
    @Suppress("NAME_SHADOWING")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<FloatingActionButton>(R.id.fabMain).setOnClickListener {
            toggleFab()
        }

        findViewById<Button>(R.id.btnRootCheck).setOnClickListener {
            findViewById<TextView>(R.id.txtHeader).text = resources.getString(R.string.title_Rooting)
            val fm = supportFragmentManager
            fm.popBackStack()
            val ft = fm.beginTransaction()
            val bf = RootingFragment()
            ft.replace(R.id.main_fragment_view, bf)
            ft.commit()
        }

        findViewById<Button>(R.id.btnFridaCheck).setOnClickListener {
            findViewById<TextView>(R.id.txtHeader).text = resources.getString(R.string.title_Frida)
            val fm = supportFragmentManager
            fm.popBackStack()
            val ft = fm.beginTransaction()
            val bf = FridaFragment()
            ft.replace(R.id.main_fragment_view, bf)
            ft.commit()
        }

        findViewById<Button>(R.id.btnEmulatorCheck).setOnClickListener {
            findViewById<TextView>(R.id.txtHeader).text = resources.getString(R.string.title_Emulator)
            val fm = supportFragmentManager
            fm.popBackStack()
            val ft = fm.beginTransaction()
            val bf = EmulatorFragment()
            ft.replace(R.id.main_fragment_view, bf)
            ft.commit()
        }

        findViewById<Button>(R.id.btnDebuggingCheck).setOnClickListener {
            findViewById<TextView>(R.id.txtHeader).text = resources.getString(R.string.title_Debugging)
            val fm = supportFragmentManager
            fm.popBackStack()
            val ft = fm.beginTransaction()
            val bf = DebuggingFragment()
            ft.replace(R.id.main_fragment_view, bf)
            ft.commit()
        }

        findViewById<Button>(R.id.btnTLSPinnerCheck).setOnClickListener {
            findViewById<TextView>(R.id.txtHeader).text = resources.getString(R.string.title_TLSPinner)
            val fm = supportFragmentManager
            fm.popBackStack()
            val ft = fm.beginTransaction()
            val bf = TLSPinnerFragment()
            ft.replace(R.id.main_fragment_view, bf)
            ft.commit()
        }

        findViewById<FragmentContainerView>(R.id.main_fragment_view).setOnTouchListener(object :
            View.OnTouchListener {
            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        if (isFabOpen)
                            toggleFab()
                    }
                    MotionEvent.ACTION_UP -> {
                        v?.performClick()
                    }
                }

                return v?.onTouchEvent(event) ?: true
            }
        })
    }

    private fun toggleFab(){
        val t1 = findViewById<Button>(R.id.btnTLSPinnerCheck)
        val t2 = findViewById<Button>(R.id.btnDebuggingCheck)
        val t3 = findViewById<Button>(R.id.btnEmulatorCheck)
        val t4 = findViewById<Button>(R.id.btnFridaCheck)
        val t5 = findViewById<Button>(R.id.btnRootCheck)

        if (isFabOpen){
            ObjectAnimator.ofFloat(t1,"translationY",0f).apply { start() }
            ObjectAnimator.ofFloat(t2,"translationY",0f).apply { start() }
            ObjectAnimator.ofFloat(t3,"translationY",0f).apply { start() }
            ObjectAnimator.ofFloat(t4,"translationY",0f).apply { start() }
            ObjectAnimator.ofFloat(t5,"translationY",0f).apply { start() }
            ObjectAnimator.ofFloat(findViewById<FloatingActionButton>(R.id.fabMain), View.ROTATION, 45f, 0f).apply { duration = 300 }.start()
            t1.visibility= View.GONE
            t2.visibility= View.GONE
            t3.visibility= View.GONE
            t4.visibility= View.GONE
            t5.visibility= View.GONE
        } else{
            ObjectAnimator.ofFloat(t1,"translationY",-200f).apply { start() }
            ObjectAnimator.ofFloat(t2,"translationY",-400f).apply { start() }
            ObjectAnimator.ofFloat(t3,"translationY",-600f).apply { start() }
            ObjectAnimator.ofFloat(t4,"translationY",-800f).apply { start() }
            ObjectAnimator.ofFloat(t5,"translationY",-1000f).apply { start() }
            ObjectAnimator.ofFloat(findViewById<FloatingActionButton>(R.id.fabMain), View.ROTATION, 0f, 45f).apply { duration = 300 }.start()
            t1.visibility= View.VISIBLE
            t2.visibility= View.VISIBLE
            t3.visibility= View.VISIBLE
            t4.visibility= View.VISIBLE
            t5.visibility= View.VISIBLE
        }
        isFabOpen = !isFabOpen
    }


}