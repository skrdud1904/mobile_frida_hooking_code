package android.com.dream_detector

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread

class FridaFragment : Fragment() {
    val handler = Handler(Looper.getMainLooper())
    var checkPortLock = false
    var checkPathLock = false
    val fridaDetector = FridaDetector()

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val x = inflater.inflate(R.layout.fragment_frida, container, false)

        val t1 = x?.findViewById<Button>(R.id.btnFridaModuleCheck)
        t1?.setOnClickListener {
            t1?.text = resources.getString(R.string.msg_Checking)
            t1?.setBackgroundResource(R.drawable.button_check)
            thread(start = true) {
                doFridaModuleCheck()
            }
        }
        val t2 = x?.findViewById<Button>(R.id.btnFridaPathCheck)
        t2?.setOnClickListener {
            t2?.text = resources.getString(R.string.msg_Checking)
            t2?.setBackgroundResource(R.drawable.button_check)
            thread(start = true) {
                doFridaPathCheck()
            }
        }
        val t3 = x?.findViewById<Button>(R.id.btnFridaPortCheck)
        t3?.setOnClickListener {
            t3?.text = resources.getString(R.string.msg_Checking)
            t3?.setBackgroundResource(R.drawable.button_check)
            thread(start = true) {
                doFridaPortCheck()
            }
        }
        return x
    }

    private fun doFridaModuleCheck() {
        handler.post {
            val t = view?.findViewById<Button>(R.id.btnFridaModuleCheck)
            if (fridaDetector.checkModule()) {
                t?.text = resources.getString(R.string.msg_Detected)
                t?.setBackgroundResource(R.drawable.button_detected)
            } else {
                t?.text = resources.getString(R.string.msg_Passed)
                t?.setBackgroundResource(R.drawable.button_passed)
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun doFridaPathCheck() {
        if (!checkPathLock) {
            checkPathLock = true
            val ret = fridaDetector.checkPath()
            thread(start = true) {
                handler.post {
                    val t = view?.findViewById<Button>(R.id.btnFridaPathCheck)
                    if (ret) {
                        t?.text = resources.getString(R.string.msg_Detected)
                        t?.setBackgroundResource(R.drawable.button_detected)
                    } else {
                        t?.text = resources.getString(R.string.msg_Passed)
                        t?.setBackgroundResource(R.drawable.button_passed)
                    }
                }
                checkPathLock = false
            }
        }
    }

    private fun doFridaPortCheck() {
        if (!checkPortLock) {
            checkPortLock = true
            val ret = fridaDetector.checkPort()
            thread(start = true) {
                handler.post {
                    val t = view?.findViewById<Button>(R.id.btnFridaPortCheck)
                    if (ret) {
                        t?.text = resources.getString(R.string.msg_Detected)
                        t?.setBackgroundResource(R.drawable.button_detected)
                    } else {
                        t?.text = resources.getString(R.string.msg_Passed)
                        t?.setBackgroundResource(R.drawable.button_passed)
                    }
                }
                checkPortLock = false
            }
        }
    }
}