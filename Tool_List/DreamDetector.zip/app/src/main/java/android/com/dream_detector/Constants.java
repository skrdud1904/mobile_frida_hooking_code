package android.com.dream_detector;

import java.util.HashMap;
import java.util.Map;

public final class Constants {
    public static final String[] knownGenyFiles = {
        "/dev/socket/genyd",
        "/dev/socket/baseband_genyd"
    };

    public static final String[] knownQemuPipes = {
        "/dev/socket/qemud",
        "/dev/qemu_pipe"
    };

    public static final String[] knownx86Files = {
        "ueventd.android_x86.rc",
        "x86.prop",
        "ueventd.ttVM_x86.rc",
        "init.ttVM_x86.rc",
        "fstab.ttVM_x86",
        "fstab.vbox86",
        "init.vbox86.rc",
        "ueventd.vbox86.rc"
    };

    public static final String[] knownAndyFiles = {
        "fstab.andy",
        "ueventd.andy.rc"
    };

    public static final String[] knownNoxFiles = {
        "fstab.nox",
        "init.nox.rc",
        "ueventd.nox.rc"
    };

    public static final Map<String, String> knownEmulatorProperties = new HashMap<String, String>() {{
        put("init.svc.qemu-props", "");
        put("qemu.hw.mainkeys", "");
        put("qemu.sf.fake_camera", "");
        put("qemu.sf.lcd_density", "");
        put("ro.bootloader", "unknown");
        put("ro.kernel.android.qemud", "");
        put("ro.kernel.qemu.gles", "");
        put("ro.kernel.qemu", "");
        put("ro.product.device", "generic");
        put("ro.product.model", "sdk");
        put("ro.product.name", "sdk");
        put("ro.serialno", "EMULATOR");
    }};

    public static final String[] knownRootAppsPackages = {
        "com.noshufou.android.su",
        "com.noshufou.android.su.elite",
        "eu.chainfire.supersu",
        "com.koushikdutta.superuser",
        "com.thirdparty.superuser",
        "com.yellowes.su",
        "com.topjohnwu.magisk",
        "com.kingroot.kinguser",
        "com.kingo.root",
        "com.smedialink.oneclickroot",
        "com.zhiqupk.root.global",
        "com.alephzain.framaroot",
        "com.koushikdutta.rommanager",
        "com.koushikdutta.rommanager.license",
        "com.dimonvideo.luckypatcher",
        "com.chelpus.lackypatch",
        "com.ramdroid.appquarantine",
        "com.ramdroid.appquarantinepro",
        "com.android.vending.billing.InAppBillingService.COIN",
        "com.android.vending.billing.InAppBillingService.LUCK",
        "com.chelpus.luckypatcher",
        "com.blackmartalpha",
        "org.blackmart.market",
        "com.allinone.free",
        "com.repodroid.app",
        "org.creeplays.hack",
        "com.baseappfull.fwd",
        "com.zmapp",
        "com.dv.marketmod.installer",
        "org.mobilism.android",
        "com.android.wp.net.log",
        "com.android.camera.update",
        "cc.madkite.freedom",
        "com.solohsu.android.edxp.manager",
        "org.meowcat.edxposed.manager",
        "com.xmodgame",
        "com.cih.game_cih",
        "com.charles.lpoqasert",
        "catch_.me_.if_.you_.can_",
        "com.devadvance.rootcloak",
        "com.devadvance.rootcloakplus",
        "de.robv.android.xposed.installer",
        "com.saurik.substrate",
        "com.zachspong.temprootremovejb",
        "com.amphoras.hidemyroot",
        "com.amphoras.hidemyrootadfree",
        "com.formyhm.hiderootPremium",
        "com.formyhm.hideroot"
    };

    public static final String[] knownSuDirectories = {
        "/data/local/",
        "/data/local/bin/",
        "/data/local/xbin/",
        "/sbin/",
        "/su/bin/",
        "/system/bin/",
        "/system/bin/.ext/",
        "/system/bin/failsafe/",
        "/system/sd/xbin/",
        "/system/usr/we-need-root/",
        "/system/xbin/",
        "/cache/",
        "/data/",
        "/dev/"
    };
    public static final String[] knownSuBinaries = {
        "su",
        "busybox",
        "magisk"
    };

}
