package android.com.dream_detector

import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.RequiresApi
import kotlin.concurrent.thread

class TLSPinnerFragment : Fragment() {
    val handler = Handler(Looper.getMainLooper())
    val tlsPinnerSender = TLSPinnerSender()
    var doSendAnHttpRequestLock = false

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val x = inflater.inflate(R.layout.fragment_tls_pinner, container, false)

        val t1 = x?.findViewById<TextView>(R.id.btnTLSTest)
        t1?.setOnClickListener {
            t1?.text = resources.getString(R.string.msg_Checking)
            t1?.setBackgroundResource(R.drawable.button_check)
            thread(start=true) {
                doSendAnHttpRequest()
            }
        }
        val t2 = x?.findViewById<TextView>(R.id.btnEnhancedTLSTest)
        t2?.setOnClickListener {
            t2?.text = resources.getString(R.string.msg_Checking)
            t2?.setBackgroundResource(R.drawable.button_check)
            thread(start=true) {
                doSendAnEnhancedPinningHttpRequest()
            }
        }
        return x
    }

    private fun doSendAnHttpRequest() {
        if (doSendAnHttpRequestLock)
            return
        doSendAnHttpRequestLock = true
        val x = tlsPinnerSender.run("https://dreamhack.io/test1")
        handler.post {
            val t = view?.findViewById<TextView>(R.id.btnTLSTest)
            if (x != null && x.contains("<title>Dreamhack</title>")){
                t?.text = resources.getString(R.string.msg_Passed)
                t?.setBackgroundResource(R.drawable.button_passed)
            } else {
                t?.text = resources.getString(R.string.msg_Detected)
                t?.setBackgroundResource(R.drawable.button_detected)
            }
        }
        doSendAnHttpRequestLock = false
    }

    private fun doSendAnEnhancedPinningHttpRequest() {
        if (doSendAnHttpRequestLock)
            return
        doSendAnHttpRequestLock = true
        val x = tlsPinnerSender.enhancedRun("https://dreamhack.io/test1")
        handler.post {
            val t = view?.findViewById<TextView>(R.id.btnEnhancedTLSTest)
            if (x != null && x.contains("<title>Dreamhack</title>")) {
                t?.text = resources.getString(R.string.msg_Passed)
                t?.setBackgroundResource(R.drawable.button_passed)
            } else {
                t?.text = resources.getString(R.string.msg_Detected)
                t?.setBackgroundResource(R.drawable.button_detected)
            }
        }
        doSendAnHttpRequestLock = false
    }
}