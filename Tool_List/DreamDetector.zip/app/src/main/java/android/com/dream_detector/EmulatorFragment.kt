package android.com.dream_detector

import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import kotlin.concurrent.thread


class EmulatorFragment : Fragment() {
    val handler = Handler(Looper.getMainLooper())

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val x = inflater.inflate(R.layout.fragment_emulator, container, false)

        val t1 = x?.findViewById<Button>(R.id.btnEmulatorFilesCheck)
        t1?.setOnClickListener {
            t1?.text = resources.getString(R.string.msg_Checking)
            t1?.setBackgroundResource(R.drawable.button_check)
            thread(start = true) {
                doEmulatorFilesCheck()
            }
        }
        val t2 = x?.findViewById<Button>(R.id.btnEmulatorPropertiesCheck)
        t2?.setOnClickListener {
            t2?.text = resources.getString(R.string.msg_Checking)
            t2?.setBackgroundResource(R.drawable.button_check)
            thread(start = true) {
                doEmulatorPropertiesCheck()
            }
        }
        return x
    }
    private fun doEmulatorFilesCheck() {
        val emulatorDetector = EmulatorDetector(context)
        handler.post {
            val t = view?.findViewById<Button>(R.id.btnEmulatorFilesCheck)
            if (emulatorDetector.checkFiles()) {
                t?.text = resources.getString(R.string.msg_Detected)
                t?.setBackgroundResource(R.drawable.button_detected)
            } else {
                t?.text = resources.getString(R.string.msg_Passed)
                t?.setBackgroundResource(R.drawable.button_passed)
            }
        }
    }

    private fun doEmulatorPropertiesCheck() {
        val emulatorDetector = EmulatorDetector(context)
        handler.post {
            val t = view?.findViewById<Button>(R.id.btnEmulatorPropertiesCheck)
            if (emulatorDetector.checkProperties()) {
                t?.text = resources.getString(R.string.msg_Detected)
                t?.setBackgroundResource(R.drawable.button_detected)
            } else {
                t?.text = resources.getString(R.string.msg_Passed)
                t?.setBackgroundResource(R.drawable.button_passed)
            }
        }
    }

}