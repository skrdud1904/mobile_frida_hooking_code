package android.com.dream_detector;

import java.util.Objects;
import java.util.concurrent.CountDownLatch;

import okhttp3.CertificatePinner;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class TLSPinnerSender {
    OkHttpClient client;
    OkHttpClient enhancedClient;
    CertificatePinner certificatePinner;

    public TLSPinnerSender() {
        client = new OkHttpClient();
        certificatePinner = new CertificatePinner.Builder()
                .add("dreamhack.io", "sha256/QnvZVPjqAxkt5Rnr/bI96PF6dFJal/p6sGBUprcSynQ=")
                .build();

        enhancedClient = new OkHttpClient.Builder()
                .certificatePinner(certificatePinner)
                .build();
    }

    String run(String url) {
        final CountDownLatch latch = new CountDownLatch(1);
        final String [] retValue = new String[1];
        Thread t = new Thread("TLS Pinner Thread - 1"){
            public synchronized void run(){
                retValue[0] = null;
                Request request = new Request.Builder()
                        .url(url)
                        .build();
                try (Response response = client.newCall(request).execute()) {
                    retValue[0] = Objects.requireNonNull(response.body()).string();
                } catch (Exception ignore) {

                }
                latch.countDown();
            }
        };
        t.start();
        try {
            latch.await();
        } catch (InterruptedException ignore) {
        }

        return retValue[0];
    }

    String enhancedRun(String url) {
        final CountDownLatch latch = new CountDownLatch(1);
        final String [] retValue = new String[1];
        Thread t = new Thread("TLS Pinner Thread - 2"){
            public synchronized void run(){
                retValue[0] = null;
                Request request = new Request.Builder()
                        .url(url)
                        .build();
                try (Response response = enhancedClient.newCall(request).execute()) {
                    retValue[0] = Objects.requireNonNull(response.body()).string();
                } catch (Exception ignore) {

                }
                latch.countDown();
            }
        };
        t.start();
        try {
            latch.await();
        } catch (InterruptedException ignore) {
        }

        return retValue[0];
    }
}
