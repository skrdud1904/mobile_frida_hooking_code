package android.com.dream_detector;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.nio.file.Files;
import java.util.concurrent.atomic.AtomicBoolean;


public class FridaDetector {
    public boolean checkPort() {
        for (int i = 26000; i < 27500; i++) {
            try {
                 Socket s = new Socket("127.0.0.1", i);
                if (s.isConnected()) {
                    return true;
                }
            } catch (IOException ignore) {
            }
        }
        return false;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public boolean checkPath() {
        // AccessDeniedException
        String dirName = "/data/local/tmp";
        try {
            AtomicBoolean found = new AtomicBoolean(false);
            Files.list(new File(dirName).toPath())
                    .limit(200)
                    .forEach(path -> {

                        if (path.toString().contains("frida"))
                            found.set(true);
                    });

            if (found.get()) {
                return true;
            }
        } catch (IOException ignore) {
        }
        return false;
    }

    public boolean checkModule() {
        File f = new File("/proc/self/maps");
        try {
            FileInputStream fio = new FileInputStream(f);
            StringBuilder resultStringBuilder = new StringBuilder();
            try (BufferedReader br
                         = new BufferedReader(new InputStreamReader(fio))) {
                String line;
                while ((line = br.readLine()) != null) {
                    resultStringBuilder.append(line).append("\n");
                }
                fio.close();
            } catch (IOException ignore) {

            }
            return resultStringBuilder.toString().contains("frida");

        } catch (FileNotFoundException ignore) {

        }
        return false;
    }
}