package android.com.dream_detector;

import android.annotation.SuppressLint;
import android.content.Context;

import java.lang.reflect.Method;

public final class Utils {
    public static String getProp(Context context, String property) {
        try {
            ClassLoader classLoader = context.getClassLoader();
            @SuppressLint("PrivateApi") Class<?> systemProperties = classLoader.loadClass("android.os.SystemProperties");

            Method get = systemProperties.getMethod("get", String.class);

            Object[] params = new Object[1];
            params[0] = property;

            return (String) get.invoke(systemProperties, params);
        } catch (Exception ignore) {
        }
        return null;
    }
}
