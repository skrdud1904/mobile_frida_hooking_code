package android.com.dream_detector

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import kotlin.concurrent.thread

class DebuggingFragment : Fragment() {
    val handler = Handler(Looper.getMainLooper())

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val x = inflater.inflate(R.layout.fragment_debugging, container, false)

        val t1 = x?.findViewById<Button>(R.id.btnDebuggingTracerCheck)
        t1?.setOnClickListener {
            t1?.text = resources.getString(R.string.msg_Checking)
            t1?.setBackgroundResource(R.drawable.button_check)
            thread(start = true) {
                doDebuggingTracerCheck()
            }
        }
        val t2 = x?.findViewById<Button>(R.id.btnDebuggingGdbPathCheck)
        t2?.setOnClickListener {
            t2?.text = resources.getString(R.string.msg_Checking)
            t2?.setBackgroundResource(R.drawable.button_check)
            thread(start = true) {
                doDebuggingGdbPathCheck()
            }
        }
        val t3 = x?.findViewById<Button>(R.id.btnDebuggingPropCheck)
        t3?.setOnClickListener {
            t3?.text = resources.getString(R.string.msg_Checking)
            t3?.setBackgroundResource(R.drawable.button_check)
            thread(start = true) {
                doDebuggingPropCheck()
            }
        }
        return x
    }

    @SuppressLint("ResourceAsColor")
    private fun doDebuggingTracerCheck() {
        val debuggingDetector = DebuggingDetector(context)
        handler.post {
            val t = view?.findViewById<Button>(R.id.btnDebuggingTracerCheck)
            if (debuggingDetector.checkProcStatus()) {
                t?.text = resources.getString(R.string.msg_Detected)
                t?.setBackgroundResource(R.drawable.button_detected)
            } else {
                t?.text = resources.getString(R.string.msg_Passed)
                t?.setBackgroundResource(R.drawable.button_passed)
            }
        }
    }

    @SuppressLint("ResourceAsColor")
    @RequiresApi(Build.VERSION_CODES.O)
    private fun doDebuggingGdbPathCheck() {
        val debuggingDetector = DebuggingDetector(context)
        handler.post {
            val t = view?.findViewById<Button>(R.id.btnDebuggingGdbPathCheck)
            if (debuggingDetector.checkPath()) {
                t?.text = resources.getString(R.string.msg_Detected)
                t?.setBackgroundResource(R.drawable.button_detected)
            } else {
                t?.text = resources.getString(R.string.msg_Passed)
                t?.setBackgroundResource(R.drawable.button_passed)
            }
        }
    }

    @SuppressLint("ResourceAsColor")
    @RequiresApi(Build.VERSION_CODES.O)
    private fun doDebuggingPropCheck() {
        val debuggingDetector = DebuggingDetector(context)
        handler.post {
            val t = view?.findViewById<Button>(R.id.btnDebuggingPropCheck)
            if (debuggingDetector.checkProp()) {
                t?.text = resources.getString(R.string.msg_Detected)
                t?.setBackgroundResource(R.drawable.button_detected)
            } else {
                t?.text = resources.getString(R.string.msg_Passed)
                t?.setBackgroundResource(R.drawable.button_passed)
            }
        }
    }
}