package android.com.dream_detector;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;

import java.io.File;

@TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
public final class EmulatorDetector {
    private final Context mContext;

    public EmulatorDetector(Context pContext) {
        mContext = pContext;
    }

    public boolean checkFiles() {
        return checkFiles(Constants.knownGenyFiles)
                || checkFiles(Constants.knownAndyFiles)
                || checkFiles(Constants.knownNoxFiles)
                || checkFiles(Constants.knownQemuPipes)
                || checkFiles(Constants.knownx86Files);
    }

    private boolean checkFiles(String[] files) {
        for (String file : files) {
            File f = new File(file);
            if (f.exists()) {
                return true;
            }
        }
        return false;
    }

    public boolean checkProperties() {
        for (String propertyName : Constants.knownEmulatorProperties.keySet()) {
            String propertyValue = Utils.getProp(mContext, propertyName);
            String property_seek = Constants.knownEmulatorProperties.get(propertyName);
            if ("".equals(property_seek) && !"".equals(propertyValue)) {
                return true;
            }
            if (!"".equals(property_seek)) {
                assert propertyValue != null;
                if (property_seek != null && propertyValue.contains(property_seek)) {
                    return true;
                }
            }
        }

        return false;
    }
}