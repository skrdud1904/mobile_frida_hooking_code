package android.com.dream_detector;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

@TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
public final class DebuggingDetector {
    private final Context mContext;
    public DebuggingDetector(Context context) {
        mContext = context;
    }

    public Boolean checkProcStatus() {
        File f = new File("/proc/self/status");
        try {
            FileInputStream fio = new FileInputStream(f);
            try (BufferedReader br
                         = new BufferedReader(new InputStreamReader(fio))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.contains("TracerPid:")) {
                        return Integer.parseInt(line.substring(11)) != 0;
                    }
                }
                fio.close();
            } catch (IOException ignore) {

            }
        } catch (FileNotFoundException ignore) {

        }
        return false;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public boolean checkPath() {
        // AccessDeniedException
        String dirName = "/data/local/tmp";
        try {
            AtomicBoolean found = new AtomicBoolean(false);
            Files.list(new File(dirName).toPath())
                    .limit(200)
                    .forEach(path -> {

                        if (path.toString().toLowerCase(Locale.ROOT).contains("gdb"))
                            found.set(true);
                    });

            if (found.get()) {
                return true;
            }
        } catch (IOException ignored) {
        }
        return false;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public boolean checkProp() {
        String property_value = Utils.getProp(mContext, "ro.debuggable");
        return property_value != null && property_value.equals("1");
    }
}
